#ifndef	TSPHERE_H
#define	TSPHERE_H

#include "TPoint3D.h"
#include "TVec3D.h"
#include "Color.h"
#include "IObject.h"
#include <type_traits>

template<typename T>
class TSphere :	public IObject<T>
{
	static_assert(std::is_pod<T>::value, "T	must be	a pod !");
public:

	TSphere()
		: m_center()
		, m_radius(1.0)
		, m_color(0.5, 0.5,	0.5, 0.0)
	{
		
	}
	
	TSphere(const TPoint3D<T>& _center,	const T& _radius, const	Color& _color)
		: m_center(_center)
		, m_radius(_radius)
		, m_color(_color)
	{
		
	}

	~TSphere() = default;

	auto GetCenter() const { return	m_center; }
	auto GetRadius() const { return	m_radius; }
	Color GetColorAt(const TPoint3D<T>& /*_position*/) const override	{ return m_color; }

	TVec3D<T> GetNormalAt(const	TPoint3D<T>& _point) override
	{
		return TVec3D<T>(m_center, _point).Normalized();
	}

	double FindIntersection(const TRay<T>& _ray) override
	{
		// TODO 1) First thing to do !
		// Write Sphere intersection algorithm.
		// Do not forget that if there is no intersection you have to return -1
	}
	
private:
	TPoint3D<T>	m_center;
	T m_radius;
	Color m_color;
};


#endif // TSPHERE_H
